/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_crud1;
import java.sql.*;

/**
 *
 * @author admin
 */
public class Java_Crud1 {
    public Statement st;
    public ResultSet rs;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException{
        // TODO code application logic here
        Connection cn = koneksi_db.KoneksiDB.BuatKoneksi();
    }
    
}

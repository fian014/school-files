/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package koneksi_db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author admin
 */
public class Koneksi_DB {
    public static Connection getKoneksi(){
    String url ="jdbc:mysql://localhost/perpustakaan";
    String user = "root";
    String password = "";
    try{
          Connection cn = DriverManager.getConnection(url, user, password);
          
          //jika koneksi berhasil maka menampilkan teks dibawah ini
          System.out.println("Berhasil terkoneksi dengan database");
          return cn;
      } catch (SQLException e){
        System.err.println(e.getMessage());
        return null;
      }
    }
}

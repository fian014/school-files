/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package java_crud;

import java.sql.*;

 public class Java_Crud {
     public Statement st;
     public ResultSet rs;
     
     
     /**
      * @param args the command line arguments
      */
     public static void main(String[] args) throws ClassNotFoundException {
         // TODO code application logic here
         Connection cn = koneksi_db.KoneksiDB.BuatKoneksi();
     }
 }


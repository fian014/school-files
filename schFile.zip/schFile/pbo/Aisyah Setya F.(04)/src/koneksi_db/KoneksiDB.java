/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package koneksi_db;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author PC-08
 */
public class KoneksiDB {
    
    public static Connection getKoneksi() {
        String url = "jdbc:mysql://localhost/db_perpus";
        String user = "root";
        String password = "";
        try {
            Connection cn = DriverManager.getConnection(url, user, password);
            
            //Jika koneksi berhasil, maka menampilkan teks dibawah ini
            System.out.println("Berhasil terkoneksi dengan database");
            return cn;
            
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
}
